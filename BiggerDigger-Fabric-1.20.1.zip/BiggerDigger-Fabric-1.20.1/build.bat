@echo off
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle was not found. Open this folder in AndroidIDE or install Gradle 8.x, then run: gradle build
  exit /b 1
)
gradle build %*
