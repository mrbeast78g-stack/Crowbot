package com.riko.biggerdigger.entity;

import net.minecraft.block.BlockState;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.ArrayDeque;
import java.util.List;
import java.util.Queue;
import java.util.UUID;

public class BiggerDiggerEntity extends PathAwareEntity {
    private UUID ownerUuid;
    private final Queue<BuildPlacement> buildQueue = new ArrayDeque<>();
    private BlockPos buildOrigin = BlockPos.ORIGIN;
    private int buildCooldown;

    public BiggerDiggerEntity(EntityType<? extends BiggerDiggerEntity> type, World world) {
        super(type, world);
        this.setPersistent();
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(2, new FollowOwnerGoal());
        this.goalSelector.add(6, new WanderAroundFarGoal(this, 0.8D) {
            @Override
            public boolean canStart() {
                return buildQueue.isEmpty() && super.canStart();
            }

            @Override
            public boolean shouldContinue() {
                return buildQueue.isEmpty() && super.shouldContinue();
            }
        });
        this.goalSelector.add(7, new LookAtEntityGoal(this, PlayerEntity.class, 8.0F));
        this.goalSelector.add(8, new LookAroundGoal(this));
    }

    public void setOwner(UUID ownerUuid) {
        this.ownerUuid = ownerUuid;
    }

    public UUID getOwnerUuid() {
        return ownerUuid;
    }

    public void startBuilding(List<BuildPlacement> placements) {
        buildQueue.clear();
        buildQueue.addAll(placements);
        buildOrigin = this.getBlockPos().toImmutable();
        buildCooldown = 0;
    }

    public int getRemainingBuildBlocks() {
        return buildQueue.size();
    }

    @Override
    public void tick() {
        super.tick();
        if (this.getWorld().isClient || buildQueue.isEmpty()) return;
        if (buildCooldown > 0) {
            buildCooldown--;
            return;
        }

        BuildPlacement next = buildQueue.peek();
        if (next == null) return;
        BlockPos target = buildOrigin.add(next.x(), next.y(), next.z());
        if (!this.getWorld().isInBuildLimit(target) || target.getY() >= this.getWorld().getTopY()) {
            buildQueue.poll();
            return;
        }

        double distance = this.squaredDistanceTo(target.getX() + 0.5D, target.getY(), target.getZ() + 0.5D);
        if (distance <= 5.0D) {
            if (this.getWorld().getBlockState(target).isAir()) {
                this.getWorld().setBlockState(target, next.state());
            }
            buildQueue.poll();
            buildCooldown = 3;
        } else if (this.getNavigation().isIdle() || this.age % 20 == 0) {
            this.getNavigation().startMovingTo(target.getX() + 0.5D, target.getY(), target.getZ() + 0.5D, 1.05D);
        }
    }

    @Override
    protected void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        if (ownerUuid != null) nbt.putUuid("Owner", ownerUuid);
    }

    @Override
    protected void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        ownerUuid = nbt.containsUuid("Owner") ? nbt.getUuid("Owner") : null;
    }

    private class FollowOwnerGoal extends Goal {
        private PlayerEntity owner;
        private int updateCountdown;

        private FollowOwnerGoal() {
            this.setControls(java.util.EnumSet.of(Control.MOVE));
        }

        @Override
        public boolean canStart() {
            if (ownerUuid == null || !(getWorld() instanceof ServerWorld serverWorld)) return false;
            owner = serverWorld.getPlayerByUuid(ownerUuid);
            return buildQueue.isEmpty() && owner != null && owner.isAlive() && squaredDistanceTo(owner) > 9.0D;
        }

        @Override
        public boolean shouldContinue() {
            return buildQueue.isEmpty() && owner != null && owner.isAlive() && squaredDistanceTo(owner) > 6.25D;
        }

        @Override
        public void start() {
            updateCountdown = 0;
        }

        @Override
        public void tick() {
            if (owner == null) return;
            if (--updateCountdown <= 0) {
                updateCountdown = 10;
                getNavigation().startMovingTo(owner, 1.15D);
            }
        }

        @Override
        public void stop() {
            owner = null;
            getNavigation().stop();
        }
    }

    public record BuildPlacement(int x, int y, int z, BlockState state) { }
}
