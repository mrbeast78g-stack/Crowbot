package com.riko.biggerdigger.client;

import com.riko.biggerdigger.config.BiggerDiggerConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

public class BiggerDiggerSettingsScreen extends Screen {
    private final Screen parent;
    private TextFieldWidget apiKeyField;
    private TextFieldWidget modelField;
    private TextFieldWidget maxBlocksField;
    private String status = "Your key is saved locally in config/biggerdigger.json";

    public BiggerDiggerSettingsScreen(Screen parent) {
        super(Text.literal("Bigger Digger Settings"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        BiggerDiggerConfig config = BiggerDiggerConfig.get();
        int left = this.width / 2 - 145;
        int top = this.height / 2 - 75;

        apiKeyField = new TextFieldWidget(textRenderer, left, top + 16, 290, 20, Text.literal("OpenRouter API key"));
        apiKeyField.setMaxLength(512);
        apiKeyField.setText(config.apiKey);
        apiKeyField.setRenderTextProvider((value, firstCharacterIndex) -> Text.literal("•".repeat(value.length()).substring(Math.min(firstCharacterIndex, value.length()))).asOrderedText());
        addDrawableChild(apiKeyField);

        modelField = new TextFieldWidget(textRenderer, left, top + 57, 290, 20, Text.literal("OpenRouter model"));
        modelField.setMaxLength(160);
        modelField.setText(config.model);
        addDrawableChild(modelField);

        maxBlocksField = new TextFieldWidget(textRenderer, left, top + 98, 90, 20, Text.literal("Max blocks"));
        maxBlocksField.setMaxLength(4);
        maxBlocksField.setText(Integer.toString(config.maxBlocks));
        addDrawableChild(maxBlocksField);

        addDrawableChild(ButtonWidget.builder(Text.literal("Save settings"), button -> save()).dimensions(left, top + 140, 140, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Cancel"), button -> close()).dimensions(left + 150, top + 140, 140, 20).build());
        setInitialFocus(apiKeyField);
    }

    private void save() {
        BiggerDiggerConfig config = BiggerDiggerConfig.get();
        config.apiKey = apiKeyField.getText().trim();
        config.model = modelField.getText().trim().isEmpty() ? "openrouter/auto" : modelField.getText().trim();
        try {
            config.maxBlocks = Math.max(32, Math.min(4096, Integer.parseInt(maxBlocksField.getText().trim())));
        } catch (NumberFormatException ignored) {
            config.maxBlocks = 768;
        }
        try {
            config.save();
            status = "Settings saved.";
            close();
        } catch (Exception exception) {
            status = "Could not save settings: " + exception.getMessage();
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context);
        int left = this.width / 2 - 145;
        int top = this.height / 2 - 75;
        context.drawCenteredTextWithShadow(textRenderer, title, this.width / 2, top - 25, 0xFFFFFF);
        context.drawTextWithShadow(textRenderer, Text.literal("OpenRouter API key"), left, top + 3, 0xFFFFFF);
        context.drawTextWithShadow(textRenderer, Text.literal("Model (default: openrouter/auto)"), left, top + 44, 0xFFFFFF);
        context.drawTextWithShadow(textRenderer, Text.literal("Maximum blocks (32–4096)"), left, top + 85, 0xFFFFFF);
        context.drawTextWithShadow(textRenderer, Text.literal(status), left, top + 169, 0xAAAAAA);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void close() {
        if (client != null) client.setScreen(parent);
    }
}
