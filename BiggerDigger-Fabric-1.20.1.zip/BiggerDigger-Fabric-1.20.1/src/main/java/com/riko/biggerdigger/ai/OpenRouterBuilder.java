package com.riko.biggerdigger.ai;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.riko.biggerdigger.config.BiggerDiggerConfig;
import com.riko.biggerdigger.entity.BiggerDiggerEntity.BuildPlacement;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public final class OpenRouterBuilder {
    private static final Gson GSON = new GsonBuilder().create();
    private static final HttpClient CLIENT = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(20)).build();

    private OpenRouterBuilder() { }

    public static CompletableFuture<List<BuildPlacement>> createPlan(BiggerDiggerConfig config, String request) {
        JsonObject payload = new JsonObject();
        payload.addProperty("model", config.model == null || config.model.isBlank() ? "openrouter/auto" : config.model);
        payload.addProperty("temperature", 0.25);
        payload.addProperty("max_tokens", 12000);

        JsonArray messages = new JsonArray();
        JsonObject system = new JsonObject();
        system.addProperty("role", "system");
        int limit = Math.max(32, Math.min(4096, config.maxBlocks));
        system.addProperty("content", "You are Bigger Digger, a Minecraft building planner. Return ONLY valid JSON, no markdown, with this exact shape: {\"blocks\":[{\"x\":0,\"y\":0,\"z\":0,\"block\":\"minecraft:stone\"}]}. Coordinates are relative to the builder NPC\'s feet. x and z MUST be between -16 and 16; y MUST be between 0 and 12. Use only real vanilla Minecraft 1.20.1 block identifiers with the minecraft: namespace. Keep the structure within " + limit + " blocks, prioritize a recognizable, complete build, include a floor and walls/roof when appropriate, and do not add commentary. Do not use command blocks, structure blocks, jigsaw blocks, barrier, or air. This is a block placement plan, not commands or code.");
        messages.add(system);
        JsonObject user = new JsonObject();
        user.addProperty("role", "user");
        user.addProperty("content", "Build this in Minecraft: " + request);
        messages.add(user);
        payload.add("messages", messages);

        HttpRequest httpRequest = HttpRequest.newBuilder(URI.create("https://openrouter.ai/api/v1/chat/completions"))
                .timeout(Duration.ofSeconds(90))
                .header("Authorization", "Bearer " + config.apiKey.trim())
                .header("Content-Type", "application/json")
                .header("X-Title", "Bigger Digger Minecraft Mod")
                .POST(HttpRequest.BodyPublishers.ofString(GSON.toJson(payload)))
                .build();

        return CLIENT.sendAsync(httpRequest, HttpResponse.BodyHandlers.ofString())
                .thenApply(response -> {
                    if (response.statusCode() < 200 || response.statusCode() >= 300) {
                        throw new IllegalStateException("OpenRouter returned HTTP " + response.statusCode() + ": " + shortText(response.body()));
                    }
                    return parsePlan(response.body(), Math.max(32, Math.min(4096, config.maxBlocks)));
                });
    }

    private static List<BuildPlacement> parsePlan(String responseBody, int maxBlocks) {
        JsonObject root = JsonParser.parseString(responseBody).getAsJsonObject();
        String content = root.getAsJsonArray("choices").get(0).getAsJsonObject()
                .getAsJsonObject("message").get("content").getAsString();
        int firstBrace = content.indexOf('{');
        int lastBrace = content.lastIndexOf('}');
        if (firstBrace < 0 || lastBrace <= firstBrace) throw new IllegalStateException("The AI did not return a JSON build plan.");
        JsonObject plan = JsonParser.parseString(content.substring(firstBrace, lastBrace + 1)).getAsJsonObject();
        JsonArray blocks = plan.getAsJsonArray("blocks");
        if (blocks == null) throw new IllegalStateException("The AI plan has no blocks array.");

        List<BuildPlacement> result = new ArrayList<>();
        for (JsonElement element : blocks) {
            if (result.size() >= maxBlocks) break;
            if (!element.isJsonObject()) continue;
            JsonObject item = element.getAsJsonObject();
            int x = item.has("x") ? item.get("x").getAsInt() : 999;
            int y = item.has("y") ? item.get("y").getAsInt() : 999;
            int z = item.has("z") ? item.get("z").getAsInt() : 999;
            String blockName = item.has("block") ? item.get("block").getAsString() : "";
            if (x < -16 || x > 16 || z < -16 || z > 16 || y < 0 || y > 12) continue;
            Identifier id = Identifier.tryParse(blockName);
            if (id == null || !"minecraft".equals(id.getNamespace())) continue;
            Block block = Registries.BLOCK.get(id);
            if (block == Blocks.AIR || block == Blocks.BEDROCK || block == Blocks.BARRIER
                    || block == Blocks.COMMAND_BLOCK || block == Blocks.STRUCTURE_BLOCK
                    || block == Blocks.JIGSAW) continue;
            result.add(new BuildPlacement(x, y, z, block.getDefaultState()));
        }
        if (result.isEmpty()) throw new IllegalStateException("The AI returned no usable block placements. Try a simpler build request.");
        return result;
    }

    private static String shortText(String text) {
        if (text == null) return "No error details";
        String cleaned = text.replace('\n', ' ').replace('\r', ' ');
        return cleaned.length() > 220 ? cleaned.substring(0, 220) + "…" : cleaned;
    }
}
