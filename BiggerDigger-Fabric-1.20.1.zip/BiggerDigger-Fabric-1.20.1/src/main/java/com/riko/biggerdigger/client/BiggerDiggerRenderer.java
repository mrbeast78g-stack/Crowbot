package com.riko.biggerdigger.client;

import com.riko.biggerdigger.BiggerDiggerMod;
import com.riko.biggerdigger.entity.BiggerDiggerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

public class BiggerDiggerRenderer extends BipedEntityRenderer<BiggerDiggerEntity, BipedEntityModel<BiggerDiggerEntity>> {
    private static final Identifier TEXTURE = new Identifier(BiggerDiggerMod.MOD_ID, "textures/entity/bigger_digger.png");

    public BiggerDiggerRenderer(EntityRendererFactory.Context context) {
        super(context, new BipedEntityModel<>(context.getPart(EntityModelLayers.PLAYER)), 0.45F);
    }

    @Override
    public Identifier getTexture(BiggerDiggerEntity entity) {
        return TEXTURE;
    }
}
