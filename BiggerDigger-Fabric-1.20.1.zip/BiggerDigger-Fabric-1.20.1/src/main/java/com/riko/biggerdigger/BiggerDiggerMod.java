package com.riko.biggerdigger;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.riko.biggerdigger.ai.OpenRouterBuilder;
import com.riko.biggerdigger.config.BiggerDiggerConfig;
import com.riko.biggerdigger.entity.BiggerDiggerEntity;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.server.command.CommandManager;

import java.util.Comparator;

public class BiggerDiggerMod implements ModInitializer {
    public static final String MOD_ID = "biggerdigger";
    public static final EntityType<BiggerDiggerEntity> BIGGER_DIGGER = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(MOD_ID, "bigger_digger"),
            EntityType.Builder.create(BiggerDiggerEntity::new, SpawnGroup.CREATURE)
                    .setDimensions(0.6F, 1.95F)
                    .maxTrackingRange(10)
                    .trackingTickInterval(3)
                    .build(MOD_ID + ":bigger_digger")
    );

    @Override
    public void onInitialize() {
        FabricDefaultAttributeRegistry.register(BIGGER_DIGGER, BiggerDiggerEntity.createMobAttributes().build());
        registerCommands();
    }

    private void registerCommands() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(CommandManager.literal("biggerdigger")
                    .then(CommandManager.literal("summon").executes(context -> {
                        ServerPlayerEntity player = context.getSource().getPlayer();
                        BiggerDiggerEntity buddy = BIGGER_DIGGER.create(player.getWorld());
                        if (buddy == null) return 0;
                        buddy.refreshPositionAndAngles(player.getX() + 1.5D, player.getY(), player.getZ() + 1.5D, player.getYaw(), 0.0F);
                        buddy.setOwner(player.getUuid());
                        buddy.setCustomName(Text.literal("Bigger Digger"));
                        buddy.setCustomNameVisible(true);
                        buddy.equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.BRICK));
                        player.getWorld().spawnEntity(buddy);
                        context.getSource().sendFeedback(() -> Text.literal("Bigger Digger: I'm here! Tell me what to build with /build <description>"), false);
                        return 1;
                    })));

            dispatcher.register(CommandManager.literal("build")
                    .then(CommandManager.argument("request", StringArgumentType.greedyString()).executes(context -> {
                        ServerPlayerEntity player = context.getSource().getPlayer();
                        BiggerDiggerConfig config = BiggerDiggerConfig.get();
                        if (config.apiKey == null || config.apiKey.isBlank()) {
                            context.getSource().sendFeedback(() -> Text.literal("Bigger Digger: Add your OpenRouter API key in the Bigger Digger settings screen (default key: B)."), false);
                            return 0;
                        }

                        BiggerDiggerEntity buddy = player.getWorld().getEntitiesByClass(
                                        BiggerDiggerEntity.class, player.getBoundingBox().expand(64.0D),
                                        entity -> player.getUuid().equals(entity.getOwnerUuid()))
                                .stream().min(Comparator.comparingDouble(player::squaredDistanceTo)).orElse(null);
                        if (buddy == null) {
                            context.getSource().sendFeedback(() -> Text.literal("Bigger Digger: Summon me first with /biggerdigger summon."), false);
                            return 0;
                        }

                        String request = StringArgumentType.getString(context, "request");
                        context.getSource().sendFeedback(() -> Text.literal("Bigger Digger: Planning your build…"), false);
                        var server = player.getServer();
                        OpenRouterBuilder.createPlan(config, request).whenComplete((placements, error) -> server.execute(() -> {
                            if (error != null) {
                                String reason = error.getCause() != null ? error.getCause().getMessage() : error.getMessage();
                                player.sendMessage(Text.literal("Bigger Digger: I couldn't make that plan. " + (reason == null ? "Check your API key and model." : reason)), false);
                                return;
                            }
                            if (buddy.isRemoved()) {
                                player.sendMessage(Text.literal("Bigger Digger: I can't find my way back. Summon me again."), false);
                                return;
                            }
                            buddy.startBuilding(placements);
                            player.sendMessage(Text.literal("Bigger Digger: Got it! Building " + placements.size() + " blocks. I'll get moving."), false);
                        }));
                        return 1;
                    })));
        });
    }
}
