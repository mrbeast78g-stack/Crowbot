package com.riko.biggerdigger.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

/** Local settings. In single-player this config is also visible to the integrated server. */
public final class BiggerDiggerConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("biggerdigger.json");
    private static BiggerDiggerConfig instance;

    public String apiKey = "";
    public String model = "openrouter/auto";
    public int maxBlocks = 768;

    private BiggerDiggerConfig() { }

    public static synchronized BiggerDiggerConfig get() {
        if (instance == null) instance = loadFromDisk();
        return instance;
    }

    private static BiggerDiggerConfig loadFromDisk() {
        if (Files.exists(FILE)) {
            try (Reader reader = Files.newBufferedReader(FILE)) {
                BiggerDiggerConfig loaded = GSON.fromJson(reader, BiggerDiggerConfig.class);
                if (loaded != null) {
                    if (loaded.apiKey == null) loaded.apiKey = "";
                    if (loaded.model == null || loaded.model.isBlank()) loaded.model = "openrouter/auto";
                    loaded.maxBlocks = Math.max(32, Math.min(4096, loaded.maxBlocks));
                    return loaded;
                }
            } catch (Exception ignored) {
                // A broken config should not prevent Minecraft from starting.
            }
        }
        return new BiggerDiggerConfig();
    }

    public synchronized void save() throws IOException {
        Files.createDirectories(FILE.getParent());
        try (Writer writer = Files.newBufferedWriter(FILE)) {
            GSON.toJson(this, writer);
        }
    }
}
