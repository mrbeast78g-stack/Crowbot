package com.riko.biggerdigger.client;

import com.riko.biggerdigger.BiggerDiggerMod;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class BiggerDiggerClient implements ClientModInitializer {
    private static KeyBinding settingsKey;

    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(BiggerDiggerMod.BIGGER_DIGGER, BiggerDiggerRenderer::new);
        settingsKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.biggerdigger.settings", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_B,
                "category.biggerdigger"));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (settingsKey.wasPressed()) {
                client.setScreen(new BiggerDiggerSettingsScreen(client.currentScreen));
            }
        });
    }
}
