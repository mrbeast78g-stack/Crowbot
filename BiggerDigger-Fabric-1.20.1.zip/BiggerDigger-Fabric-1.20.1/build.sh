#!/usr/bin/env sh
set -eu
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle was not found. Open this folder in AndroidIDE or install Gradle 8.x, then run: gradle build" >&2
  exit 1
fi
exec gradle build "$@"
