# Bigger Digger — Fabric 1.20.1

A source project for a physical Minecraft builder companion. Target runtime:

- Minecraft Java Edition **1.20.1**
- Fabric Loader **0.19.5**
- Fabric API **0.92.12+1.20.1**
- Java **17**
- Yarn **1.20.1+build.10**
- Fabric Loom **1.3.10**

## What is in this first build

- A summonable custom humanoid NPC called **Bigger Digger** with a hard-hat builder texture and pickaxe.
- Follows the player who summoned it, looks at nearby players, and wanders while idle.
- `/biggerdigger summon` summons and assigns the companion to you.
- `/build <description>` sends the request to OpenRouter and asks the model for a structured block-placement plan.
- Bigger Digger walks to the planned locations and places blocks gradually rather than instantly filling the whole structure.
- Press **B** by default to open the Bigger Digger settings screen. The key can be changed under Options → Controls.
- Settings include OpenRouter API key, model ID, and maximum block count.

This is an early playable foundation, not a finished autonomous construction AI. It currently builds using vanilla block IDs and a bounded relative build area (x/z −16..16, y 0..12). It does not yet mine terrain, gather materials, construct redstone logic, or understand arbitrary modded blocks. Placements are limited to air blocks so it will not deliberately overwrite existing builds.

## Add your OpenRouter key

1. Launch Minecraft with this mod installed.
2. Press **B** to open Bigger Digger Settings.
3. Paste your OpenRouter API key.
4. Set a model ID. `openrouter/auto` is the default; use a model ID available to your OpenRouter account. Some models require credits.
5. Save settings.

The key is stored locally as plaintext in `config/biggerdigger.json`, so keep that file private. It is not included in this ZIP or sent to other players by the mod. In single-player, the integrated server reads the same local config. For a dedicated multiplayer server, install the mod on the server and configure the server's own `config/biggerdigger.json`; the server makes the AI request.

## Play

In a world with cheats enabled (or as an operator on a server):

```text
/biggerdigger summon
/build a modern two-floor house with a balcony
/build a small medieval watchtower
/build a garden with paths and a fountain
```

Bigger Digger must be nearby and belong to the player issuing `/build`.

## Build the mod JAR

This ZIP contains the Gradle project source. It does not contain a precompiled JAR or a Gradle wrapper binary.

Use JDK 17 and Gradle 8.x (the project uses Kotlin DSL; Loom is pinned to 1.3.10 for compatibility with older Gradle 8 installations):

```bash
gradle build
```

The built mod will be written to:

```text
build/libs/biggerdigger-0.1.0.jar
```

Install Fabric API `0.92.12+1.20.1` in the Minecraft `mods` folder alongside the built JAR. The ZIP is intended to be opened/imported as a Gradle project in AndroidIDE or another Java IDE; do not put the ZIP itself in the `mods` folder.

## Safety / reliability limits

- API output is treated as untrusted data and parsed as a strict JSON block plan.
- Only `minecraft:` block IDs are accepted.
- Command blocks, structure blocks, jigsaw blocks, barrier, bedrock, and air are rejected.
- Coordinates and block counts are bounded before placement.
- The API key is kept in the local config file, not hard-coded in source.
- OpenRouter requests require internet access and may incur usage charges depending on the selected model/account.

## Project layout

```text
src/main/java/com/riko/biggerdigger/
  BiggerDiggerMod.java
  ai/OpenRouterBuilder.java
  config/BiggerDiggerConfig.java
  entity/BiggerDiggerEntity.java
  client/BiggerDiggerClient.java
  client/BiggerDiggerRenderer.java
  client/BiggerDiggerSettingsScreen.java
src/main/resources/
  fabric.mod.json
  assets/biggerdigger/textures/entity/bigger_digger.png
```
